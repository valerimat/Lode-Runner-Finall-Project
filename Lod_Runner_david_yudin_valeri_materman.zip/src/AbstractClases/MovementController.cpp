#include "MovementController.h"
#include "Map.h"

//Ctors
MovementController::MovementController(Map* map) :
	m_map(map)
{
};
//-----------------------------------------------------------------------------
