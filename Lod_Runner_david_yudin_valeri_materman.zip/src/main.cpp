
#include "GameController.h"
#include <iostream>

int main()
{
	GameController::Run();

	return 0;
}
